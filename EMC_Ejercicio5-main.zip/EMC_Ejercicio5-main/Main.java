package Ejercicio5;

public class Principal {
 
    public static void main(String[] args) {
       Raices ecuacion=new Raices(1,4,4); 
       ecuacion.calcular(); 
        
    }
     
}
