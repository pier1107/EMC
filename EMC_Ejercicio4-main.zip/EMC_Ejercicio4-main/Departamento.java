package EMC;

public class Departamento {
    public String nombre;
    public String provincia;
    public String distrito;

    Departamento(String nombre, String provincia, String distrito) {
        setNombre(nombre);
        setProvincia(provincia);
        setDistrito(distrito);

    }

    void setNombre(String nombre) {
        this.nombre = nombre;
    }

    String getNombre() {
        return nombre;
    }

    void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    String getProvincia() {
        return provincia;
    }

    void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    String getDistrito() {
        return distrito;
    }

}
