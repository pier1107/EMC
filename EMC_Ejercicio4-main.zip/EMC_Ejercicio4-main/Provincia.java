package EMC;

public class Provincia {
    public String nombre;
    public Distrito distrito;

    Provincia(String nombre, Distrito distrito) {
        setNombre(nombre);
        setDistrito(distrito);
    }

    private void setNombre(String nombre2) {
    }

    void SetNombre(String nombre) {
        this.nombre = nombre;
    }

    String getNombre() {
        return nombre;
    }

    void setDistrito(Distrito distrito) {
        this.distrito = distrito;
    }

    Distrito getDistrito() {
        return distrito;
    }
}
