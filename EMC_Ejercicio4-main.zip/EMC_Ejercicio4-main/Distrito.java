package EMC;

public class Distrito {
    public String nombre;

    Distrito(String nombre) {
        setNombre(nombre);
    }

    void setNombre(String nombre) {
        this.nombre = nombre;
    }

    String getNombre() {
        return nombre;
    }
}
